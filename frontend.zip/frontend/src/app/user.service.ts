import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class UserService {
  constructor(private httpClient: HttpClient) { }

  addUser(user: any) {
    return this.httpClient.post("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/registeruser", user);
  }

  loginuser(user: any) {
    return this.httpClient.post("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/userlogin", user);
  }

  forgotPwd(user: any) {
    return this.httpClient.put("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/forgetpassword", user);
  }

  gettweets() {
    return this.httpClient.get("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/gettweets");
  }

  addtweet(user: any) {
    return this.httpClient.post("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/addtweet", user);
  }

  resetpass(user: any) {
    return this.httpClient.put("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/resetpassword", user);
  }

  postcomments(user: any) {
    return this.httpClient.post("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/postcomments", user);
  }

  getAllUsers() {
    return this.httpClient.get("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/getallusers");
  }

  getAllTweets() {
    return this.httpClient.get("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/getusertweet/?email=" + sessionStorage.getItem('email'));
  }

  deletTweet(index: any) {
    return this.httpClient.delete("https://2u5f40ia16.execute-api.us-east-1.amazonaws.com/dev/deletetweet/?tweetId=" + index);
  }

}
