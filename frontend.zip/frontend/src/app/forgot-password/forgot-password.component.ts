import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  forgotPwdForm:any;
  errorMessage:any;
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
    this.forgotPwdForm = new FormGroup({
      'email': new FormControl('', [Validators.required]),
      'password': new FormControl('', [Validators.required])
      });
  }

  submit(forgotPwdForm:any) {
    this.errorMessage=null;
    this.userService.forgotPwd(forgotPwdForm.value).subscribe((response:any) =>{
      if(response == false)
      {
        this.errorMessage="Incorrect Credentials, please try again";
      }
      else {
        this.router.navigate(['/login'])
      }
    },(error) => {
      console.log(error);
       })
  }
  navigate(screen) {
    if(screen === 'google') {
      location.replace('https://www.gmail.com');
    } else if(screen === 'fb') {
      location.replace('https://www.facebook.com');
    }
  }

}
